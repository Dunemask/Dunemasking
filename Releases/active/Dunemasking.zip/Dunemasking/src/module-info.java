/**
 * 
 */
/**
 * @author dunem
 *
 */
module dunemasking {
	requires java.base;
	requires java.scripting;
	requires java.desktop;
	exports dunemask.xml;
	exports testing.fileutil;
	exports dunemask.util;
}
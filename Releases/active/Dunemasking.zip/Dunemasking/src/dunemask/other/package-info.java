/**Other Things that you might want from Dunemasking
 * <p>Encrypting for Strings: {@link dunemask.other.StringBasedEncryption} </p>
 * @author Elijah
 * 
 */
package dunemask.other;

/*
 * 
 * <?xml version="1.0" encoding="UTF-8"?>

<?import java.lang.*?>
<?import java.util.*?>
<?import java.scene.*?>
<?import java.scene.control*?>
<?import java.scene.layout.*?>

<AnchorPane id="AnchorPane" prefHeight="200" prefWidth="320" xmlns:fx="http://javafx.com/fxml/1" fx:controller="dunemask.other.FXMLDocumentController">
	<children>
		<Button layoutX="126" layoutY="90" text = "Click Me!" onAction="#handleButtonAction" fx:id="button" />
		<Label layoutX="126" layoutY="120" minHeight="16" minWidth="69" fx:id="label" />
	</children>
</AnchorPane>
 * 
 * 
 * */

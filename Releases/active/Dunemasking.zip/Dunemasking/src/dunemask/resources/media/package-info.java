/** 
 * Dunemask Created This File on the Main Repository
 * @contact Dunemask at dunemask@gmail.com
 * File: dunemask.resources.media.package-info.java
 * Version: 0.1
 * info: (Information About The Class)
 * (To Change This Go To Window > Preferences 
 * > Java > Code Style > Code Templates)
 * <p>Belongs to Package {@link dunemask.resources.media }</p>
 */
/**
 * @author Elijah
 */
package dunemask.resources.media;
Thank You For Running This Program!
This is an original program made by Elijah Parker.
All Gif's,Names,Logo's,and Music are owned and Distributed by there respected owners.
However all formatting and graphical use of these items are all original any replication or resemblence is simply coincidence.
ENJOY!
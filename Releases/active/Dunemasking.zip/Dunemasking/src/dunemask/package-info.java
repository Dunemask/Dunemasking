/**Dunemasking project
 * <p> Thank you for supporting Dunemasking!</p>
 * <p>Dunemasking {@link dunemask.dunemasking}</p>
 * <p>Dunemasking Objects {@link dunemask.objects}</p>
 * <p>Utilities {@link dunemask.util}</p>
 * <p>Dunemasking Resources {@link dunemask.resources}</p>
 * <p>Other Dunemasking Classes {@link dunemask.other}</p>
 * @author Elijah
 * 
 */
package dunemask;


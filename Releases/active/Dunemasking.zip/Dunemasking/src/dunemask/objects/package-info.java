/**Useful Objects that programs can use
 * @author Elijah
 * <p>MediaUtil Music Player: {@link dunemask.objects.MusicPlayer}</p>
 *  <p>JLabel image: {@link dunemask.objects.ScaledImageLabel}</p>
 *  * <p>Math Expressions: {@link dunemask.objects.Expression}</p>
 * 
 */
package dunemask.objects;


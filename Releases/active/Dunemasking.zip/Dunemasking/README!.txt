ALL OF THE FOLLOWING IS UNDER FAIR USE COPYRIGHT, DO NOT TAKE CREDIT FOR MY WORK!

Use this for commercial, purpose, or whatever you want, would love to hear what you're using it fore! :3

email:dunemask@outlook.com
Ver: JDK-8